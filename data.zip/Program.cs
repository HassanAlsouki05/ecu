using Microsoft.EntityFrameworkCore;
using data1.Data;
using data1.Repositories;
using data1.Services.YourProjectName.Services;
using data1.Entities;
using data1.Properties;

var builder = WebApplication.CreateBuilder(args);

// L�gg till DbContext (SQL Server)
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// L�gg till Repositories & Services
builder.Services.AddScoped<IRepository<Project>, ProjectRepository>();
builder.Services.AddScoped<IProjectService, ProjectService>();

// L�gg till MVC
builder.Services.AddControllersWithViews();

var app = builder.Build();

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Project}/{action=Index}/{id?}");

app.Run();
