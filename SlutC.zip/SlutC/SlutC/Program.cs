﻿using Newtonsoft.Json;
using System.Xml;

namespace ContactApp
{
    // Representerar en kontakt
    public class Contact
    {
        public string Name { get; set; }
        public string PhoneNumber { get; set; }

        public Contact(string name, string phoneNumber)
        {
            Name = name;
            PhoneNumber = phoneNumber;
        }
    }

    // Hanterar kontakter
    public class ContactManager
    {
        private List<Contact> contacts;
        private const string FilePath = "contacts.json";

        public ContactManager()
        {
            contacts = LoadContacts();
        }

        // Laddar kontakter från en JSON-fil
        public List<Contact> LoadContacts()
        {
            if (File.Exists(FilePath))
            {
                var jsonData = File.ReadAllText(FilePath);
                return JsonConvert.DeserializeObject<List<Contact>>(jsonData) ?? new List<Contact>();
            }
            return new List<Contact>();
        }

        // Sparar kontakter till en JSON-fil
        public void SaveContacts()
        {
            var jsonData = JsonConvert.SerializeObject(contacts, Newtonsoft.Json.Formatting.Indented);
            File.WriteAllText(FilePath, jsonData);
        }

        // Lägg till en ny kontakt
        public void AddContact(Contact contact)
        {
            contacts.Add(contact);
        }

        // Lista alla kontakter
        public void ListContacts()
        {
            if (contacts.Count == 0)
            {
                Console.WriteLine("Inga kontakter finns.");
                return;
            }

            foreach (var contact in contacts)
            {
                Console.WriteLine($"Namn: {contact.Name}, Telefonnummer: {contact.PhoneNumber}");
            }
        }

        // Hämtar alla kontakter
        public List<Contact> GetAllContacts()
        {
            return contacts;
        }
    }

    // Applikationen med användarmeny
    class Program
    {
        static void Main(string[] args)
        {
            var contactManager = new ContactManager();
            bool running = true;

            while (running)
            {
                Console.Clear();
                Console.WriteLine("Välj ett alternativ:");
                Console.WriteLine("1. Lista alla kontakter");
                Console.WriteLine("2. Skapa en ny kontakt");
                Console.WriteLine("3. Spara kontakter");
                Console.WriteLine("4. Ladda kontakter");
                Console.WriteLine("5. Avsluta");

                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        contactManager.ListContacts();
                        break;
                    case "2":
                        Console.WriteLine("Ange namn på kontakt:");
                        string name = Console.ReadLine();
                        Console.WriteLine("Ange telefonnummer:");
                        string phone = Console.ReadLine();
                        var newContact = new Contact(name, phone);
                        contactManager.AddContact(newContact);
                        break;
                    case "3":
                        contactManager.SaveContacts();
                        Console.WriteLine("Kontakter sparade.");
                        break;
                    case "4":
                        contactManager.LoadContacts();
                        Console.WriteLine("Kontakter inlästa.");
                        break;
                    case "5":
                        running = false;
                        break;
                    default:
                        Console.WriteLine("Ogiltigt val.");
                        break;
                }

                Console.WriteLine("Tryck på en tangent för att fortsätta...");
                Console.ReadKey();
            }
        }
    }
}
