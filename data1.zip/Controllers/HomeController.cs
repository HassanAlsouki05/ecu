using data1.Properties;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using data1.Entities;

namespace data1.Controllers
{
    public class ProjectController : Controller
    {
        private readonly IProjectService _projectService;

        public ProjectController(IProjectService projectService)
        {
            _projectService = projectService;
        }

        public IActionResult Index()
        {
            IEnumerable<Project> projects = _projectService.GetAllProjects();
            return View(projects);
        }

        public IActionResult Create() => View();

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Project project)
        {
            if (ModelState.IsValid)
            {
                _projectService.CreateProject(project);
                return RedirectToAction(nameof(Index));
            }
            return View(project);
        }

        public IActionResult Edit(int id)
        {
            var project = _projectService.GetProjectById(id);
            return project == null ? NotFound() : View(project);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(Project project)
        {
            if (ModelState.IsValid)
            {
                _projectService.UpdateProject(project);
                return RedirectToAction(nameof(Index));
            }
            return View(project);
        }
    }
}
