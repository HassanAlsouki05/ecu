using Microsoft.EntityFrameworkCore;
using data1.Entities;


namespace data1.Entities
{
    public class Customer
    {
        public int CustomerId { get; set; }
        public string Name { get; set; }
        public ICollection<Project> Projects { get; set; } = new List<Project>();
    }
}
namespace data1.Entities
{
    public class Project
    {
        public int ProjectId { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }

        public int CustomerId { get; set; }
        public Customer Customer { get; set; }
    }
}
namespace data1.Models  // �ndra "YourProjectName" till ditt projekt-namn
{
    public class ErrorViewModel
    {
        public string? RequestId { get; set; }
        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    }
}
