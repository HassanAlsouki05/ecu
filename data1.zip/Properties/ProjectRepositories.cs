﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using data1.Data;
using data1.Entities;
using data1.Repositories;

namespace data1.Properties
{
    public class ProjectRepository : IRepository<Project>
    {
        private readonly AppDbContext _context;

        public ProjectRepository(AppDbContext context)
        {
            _context = context;
        }

        public IEnumerable<Project> GetAll() => _context.Projects.Include(p => p.Customer).ToList();
        public Project GetById(int id) => _context.Projects.Include(p => p.Customer).FirstOrDefault(p => p.ProjectId == id);
        public void Add(Project entity) { _context.Projects.Add(entity); }
        public void Update(Project entity) { _context.Projects.Update(entity); }
        public void Delete(int id)
        {
            var project = _context.Projects.Find(id);
            if (project != null) _context.Projects.Remove(project);
        }
        public void Save() { _context.SaveChanges(); }
    }
}
