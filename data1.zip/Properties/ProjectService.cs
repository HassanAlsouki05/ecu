﻿using System.Diagnostics;
using data1.Properties;
using data1.Entities;
using data1.Repositories;

namespace data1.Services
{

    namespace YourProjectName.Services
    {
        [DebuggerDisplay($"{{{nameof(GetDebuggerDisplay)}(),nq}}")]
        public class ProjectService : IProjectService
        {
            private readonly IRepository<Project> _projectRepository;

            public ProjectService(IRepository<Project> projectRepository)
            {
                _projectRepository = projectRepository;
            }

            public IEnumerable<Project> GetAllProjects() => _projectRepository.GetAll();
            public Project GetProjectById(int id) => _projectRepository.GetById(id);
            public void CreateProject(Project project)
            {
                _projectRepository.Add(project);
                _projectRepository.Save();
            }
            public void UpdateProject(Project project)
            {
                _projectRepository.Update(project);
                _projectRepository.Save();
            }
            public void DeleteProject(int id)
            {
                _projectRepository.Delete(id);
                _projectRepository.Save();
            }

            private string GetDebuggerDisplay() => ToString();
        }
    }
}




